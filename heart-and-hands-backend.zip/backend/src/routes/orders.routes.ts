import { Router } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { prisma } from '../lib/prisma';
import { attachUser, requireAuth, requireRole } from '../middleware/auth';

const router = Router();

function orderNumber() {
  return `HH-${Date.now().toString(36).toUpperCase()}`;
}

function serialize(o: any) {
  return {
    ...o,
    shippingAddress: {
      fullName: o.shipFullName,
      street: o.shipStreet,
      apartment: o.shipApartment,
      city: o.shipCity,
      state: o.shipState,
      zipCode: o.shipZipCode,
      country: o.shipCountry,
    },
    items: (o.items || []).map((it: any) => ({
      cartItemId: it.id,
      productId: it.productId,
      product: it.product,
      quantity: it.quantity,
      totalPrice: it.totalPrice,
      customSelections: {
        engravingText: it.engravingText,
        material: it.material,
        font: it.font,
        giftWrap: it.giftWrap,
        giftMessage: it.giftMessage,
        specialInstructions: it.specialInstructions,
      },
    })),
    timeline: o.timeline || [],
  };
}

// Customer: place an order (cart -> order)
router.post('/', attachUser, requireRole('customer'), async (req, res) => {
  const b = req.body || {};
  const customer = await prisma.user.findUnique({ where: { id: req.user!.userId } });
  if (!customer) return res.status(404).json({ error: 'Customer not found' });

  const items = b.items || []; // [{ productId, quantity, totalPrice, customSelections }]
  if (!items.length) return res.status(400).json({ error: 'Order must include at least one item' });

  const order = await prisma.order.create({
    data: {
      id: uuidv4(),
      orderNumber: orderNumber(),
      customerId: customer.id,
      customerName: customer.fullName,
      customerEmail: customer.email,
      customerPhone: customer.phoneNumber,
      shipFullName: b.shippingAddress?.fullName,
      shipStreet: b.shippingAddress?.street,
      shipApartment: b.shippingAddress?.apartment,
      shipCity: b.shippingAddress?.city,
      shipState: b.shippingAddress?.state,
      shipZipCode: b.shippingAddress?.zipCode,
      shipCountry: b.shippingAddress?.country,
      subtotal: b.subtotal ?? 0,
      discount: b.discount ?? 0,
      shippingFee: b.shippingFee ?? 0,
      tax: b.tax ?? 0,
      total: b.total ?? 0,
      status: 'Pending',
      paymentStatus: b.paymentStatus || 'Pending',
      items: {
        create: await Promise.all(items.map(async (it: any) => {
          const product = await prisma.product.findUnique({ where: { id: it.productId } });
          return {
            id: uuidv4(),
            productId: it.productId,
            artisanId: product?.artisanId || '',
            quantity: it.quantity ?? 1,
            totalPrice: it.totalPrice ?? 0,
            engravingText: it.customSelections?.engravingText,
            material: it.customSelections?.material,
            font: it.customSelections?.font,
            giftWrap: it.customSelections?.giftWrap ?? false,
            giftMessage: it.customSelections?.giftMessage,
            specialInstructions: it.customSelections?.specialInstructions,
          };
        })),
      },
      timeline: {
        create: [{ id: uuidv4(), status: 'Pending', note: 'Order placed' }],
      },
    },
    include: { items: { include: { product: true } }, timeline: true },
  });

  // Notify each artisan involved in this order.
  const artisanIds = Array.from(new Set(order.items.map(i => i.artisanId).filter(Boolean)));
  await Promise.all(artisanIds.map(artisanId => prisma.artisanNotification.create({
    data: {
      id: uuidv4(),
      artisanId,
      type: 'new_order',
      title: 'New order received',
      message: `You have a new order (${order.orderNumber}).`,
      orderId: order.id,
    },
  })));

  res.status(201).json({ order: serialize(order) });
});

// Customer: list own orders
router.get('/mine', attachUser, requireAuth, async (req, res) => {
  const orders = await prisma.order.findMany({
    where: { customerId: req.user!.userId },
    include: { items: { include: { product: true } }, timeline: true },
    orderBy: { createdAt: 'desc' },
  });
  res.json({ orders: orders.map(serialize) });
});

// Artisan: list orders containing their products
router.get('/artisan/mine', attachUser, requireRole('artisan'), async (req, res) => {
  const orders = await prisma.order.findMany({
    where: { items: { some: { artisanId: req.user!.userId } } },
    include: { items: { include: { product: true } }, timeline: true },
    orderBy: { createdAt: 'desc' },
  });
  res.json({ orders: orders.map(serialize) });
});

// Single order (owner customer or an artisan with items in it)
router.get('/:id', attachUser, requireAuth, async (req, res) => {
  const order = await prisma.order.findUnique({
    where: { id: req.params.id },
    include: { items: { include: { product: true } }, timeline: true },
  });
  if (!order) return res.status(404).json({ error: 'Order not found' });

  const isOwner = order.customerId === req.user!.userId;
  const isInvolvedArtisan = order.items.some(i => i.artisanId === req.user!.userId);
  if (!isOwner && !isInvolvedArtisan) {
    return res.status(403).json({ error: 'Not authorized to view this order' });
  }
  res.json({ order: serialize(order) });
});

// Artisan: update order status (adds a timeline event)
router.patch('/:id/status', attachUser, requireRole('artisan'), async (req, res) => {
  const { status, note, trackingNumber, carrier } = req.body || {};
  const order = await prisma.order.findUnique({ where: { id: req.params.id }, include: { items: true } });
  if (!order) return res.status(404).json({ error: 'Order not found' });
  if (!order.items.some(i => i.artisanId === req.user!.userId)) {
    return res.status(403).json({ error: 'Not authorized to update this order' });
  }

  const updated = await prisma.order.update({
    where: { id: order.id },
    data: {
      status,
      ...(trackingNumber ? { trackingNumber } : {}),
      ...(carrier ? { carrier } : {}),
      timeline: { create: [{ id: uuidv4(), status, note }] },
    },
    include: { items: { include: { product: true } }, timeline: true },
  });

  await prisma.artisanNotification.create({
    data: {
      id: uuidv4(),
      artisanId: req.user!.userId,
      type: status === 'Completed' ? 'completed_order' : 'new_order',
      title: `Order ${order.orderNumber} updated`,
      message: `Status changed to ${status}.`,
      orderId: order.id,
    },
  }).catch(() => {}); // best-effort

  res.json({ order: serialize(updated) });
});

export default router;
