import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import { prisma } from '../lib/prisma';
import { signSession, setSessionCookie, clearSessionCookie, attachUser } from '../middleware/auth';
import { loadOAuthConfig, getRedirectUri, ALLOWED_ORIGINS } from '../lib/oauth';

const router = Router();

function toPublicUser(u: any) {
  const { passwordHash, googleId, ...rest } = u;
  return rest;
}

// ---------- Local email/password ----------

router.post('/register', async (req, res) => {
  const { fullName, email, phoneNumber, password, role, shopName } = req.body || {};

  if (!fullName || !email || !password || !role) {
    return res.status(400).json({ error: 'fullName, email, password and role are required' });
  }
  if (!['customer', 'artisan'].includes(role)) {
    return res.status(400).json({ error: "role must be 'customer' or 'artisan'" });
  }

  const existing = await prisma.user.findUnique({ where: { email: email.toLowerCase() } });
  if (existing) {
    return res.status(409).json({ error: 'An account with this email already exists' });
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const user = await prisma.user.create({
    data: {
      id: uuidv4(),
      fullName,
      email: email.toLowerCase(),
      phoneNumber,
      role,
      passwordHash,
      authProvider: 'local',
      shopName: role === 'artisan' ? shopName : undefined,
    },
  });

  const token = signSession({ userId: user.id, role: user.role as any, email: user.email });
  setSessionCookie(res, token);
  res.status(201).json({ user: toPublicUser(user), token });
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) {
    return res.status(400).json({ error: 'email and password are required' });
  }

  const user = await prisma.user.findUnique({ where: { email: email.toLowerCase() } });
  if (!user || !user.passwordHash) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }

  const token = signSession({ userId: user.id, role: user.role as any, email: user.email });
  setSessionCookie(res, token);
  res.json({ user: toPublicUser(user), token });
});

router.post('/logout', (_req, res) => {
  clearSessionCookie(res);
  res.json({ ok: true });
});

router.get('/me', attachUser, async (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not authenticated' });
  const user = await prisma.user.findUnique({ where: { id: req.user.userId } });
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ user: toPublicUser(user) });
});

// ---------- Google OAuth ----------
// Uses the client's existing oauth.ts (redirect URI resolution, allowed origins/callbacks).

router.get('/google/start', (req, res) => {
  const { clientId } = loadOAuthConfig();
  if (!clientId) {
    return res.status(500).json({ error: 'Google OAuth is not configured on the server' });
  }
  const explicitRedirect = typeof req.query.redirectUri === 'string' ? req.query.redirectUri : undefined;
  const redirectUri = getRedirectUri(req, explicitRedirect);

  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: 'openid email profile',
    access_type: 'offline',
    prompt: 'consent',
    // carry the intended role (customer/artisan) through the OAuth round trip
    state: typeof req.query.role === 'string' ? req.query.role : 'customer',
  });

  res.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`);
});

router.get('/google/callback', async (req, res) => {
  const { code, state } = req.query;
  const { clientId, clientSecret } = loadOAuthConfig();

  if (!code || typeof code !== 'string') {
    return res.status(400).json({ error: 'Missing authorization code' });
  }
  if (!clientId || !clientSecret) {
    return res.status(500).json({ error: 'Google OAuth is not configured on the server' });
  }

  const redirectUri = getRedirectUri(req);

  try {
    const tokenResp = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: clientId,
        client_secret: clientSecret,
        redirect_uri: redirectUri,
        grant_type: 'authorization_code',
      }),
    });
    const tokenData: any = await tokenResp.json();
    if (!tokenData.access_token) {
      return res.status(401).json({ error: 'Google token exchange failed', details: tokenData });
    }

    const profileResp = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: { Authorization: `Bearer ${tokenData.access_token}` },
    });
    const profile: any = await profileResp.json();

    const role = (typeof state === 'string' && ['customer', 'artisan'].includes(state)) ? state : 'customer';

    let user = await prisma.user.findUnique({ where: { email: profile.email.toLowerCase() } });
    if (!user) {
      user = await prisma.user.create({
        data: {
          id: uuidv4(),
          fullName: profile.name || profile.email,
          email: profile.email.toLowerCase(),
          role,
          authProvider: 'google',
          googleId: profile.id,
          avatar: profile.picture,
        },
      });
    }

    const token = signSession({ userId: user.id, role: user.role as any, email: user.email });
    setSessionCookie(res, token);

    // Redirect back to the frontend that initiated the flow.
    const origin = ALLOWED_ORIGINS.find(o => redirectUri.startsWith(o)) || ALLOWED_ORIGINS[0];
    res.redirect(`${origin}/auth/success?token=${encodeURIComponent(token)}`);
  } catch (err) {
    console.error('Google OAuth callback error:', err);
    res.status(500).json({ error: 'Google authentication failed' });
  }
});

export default router;
