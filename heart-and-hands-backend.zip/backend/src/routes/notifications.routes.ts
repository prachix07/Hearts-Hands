import { Router } from 'express';
import { prisma } from '../lib/prisma';
import { attachUser, requireRole } from '../middleware/auth';

const router = Router();

router.get('/', attachUser, requireRole('artisan'), async (req, res) => {
  const notifications = await prisma.artisanNotification.findMany({
    where: { artisanId: req.user!.userId },
    orderBy: { createdAt: 'desc' },
  });
  res.json({ notifications });
});

router.patch('/:id/read', attachUser, requireRole('artisan'), async (req, res) => {
  const notif = await prisma.artisanNotification.findUnique({ where: { id: req.params.id } });
  if (!notif || notif.artisanId !== req.user!.userId) {
    return res.status(404).json({ error: 'Notification not found' });
  }
  const updated = await prisma.artisanNotification.update({
    where: { id: notif.id },
    data: { read: true },
  });
  res.json({ notification: updated });
});

export default router;
