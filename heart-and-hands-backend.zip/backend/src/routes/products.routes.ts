import { Router } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { prisma } from '../lib/prisma';
import { attachUser, requireRole } from '../middleware/auth';

const router = Router();

function serialize(p: any) {
  return {
    ...p,
    images: p.images ? JSON.parse(p.images) : [],
    customOptions: {
      allowEngraving: p.allowEngraving,
      engravingPlaceholder: p.engravingPlaceholder,
      engravingMaxChars: p.engravingMaxChars,
      materials: p.materials ? JSON.parse(p.materials) : [],
      fonts: p.fonts ? JSON.parse(p.fonts) : [],
      giftWrapAvailable: p.giftWrapAvailable,
    },
  };
}

// Public: list/search products
router.get('/', async (req, res) => {
  const { category, subcategory, artisanId, q } = req.query;
  const products = await prisma.product.findMany({
    where: {
      ...(category ? { mainCategory: String(category) } : {}),
      ...(subcategory ? { subcategory: String(subcategory) } : {}),
      ...(artisanId ? { artisanId: String(artisanId) } : {}),
      ...(q ? { title: { contains: String(q) } } : {}),
    },
    orderBy: { createdAt: 'desc' },
  });
  res.json({ products: products.map(serialize) });
});

// Public: single product
router.get('/:id', async (req, res) => {
  const product = await prisma.product.findUnique({ where: { id: req.params.id } });
  if (!product) return res.status(404).json({ error: 'Product not found' });
  res.json({ product: serialize(product) });
});

// Artisan: create product
router.post('/', attachUser, requireRole('artisan'), async (req, res) => {
  const b = req.body || {};
  const artisan = await prisma.user.findUnique({ where: { id: req.user!.userId } });
  if (!artisan) return res.status(404).json({ error: 'Artisan not found' });

  const product = await prisma.product.create({
    data: {
      id: uuidv4(),
      title: b.title,
      description: b.description,
      category: b.category,
      mainCategory: b.mainCategory,
      subcategory: b.subcategory,
      price: b.price,
      artisanId: artisan.id,
      artisanName: artisan.fullName,
      artisanShop: artisan.shopName || artisan.fullName,
      image: b.image,
      images: JSON.stringify(b.images || []),
      inStock: b.inStock ?? true,
      stockCount: b.stockCount ?? 0,
      status: b.status || 'Active',
      allowEngraving: b.customOptions?.allowEngraving ?? false,
      engravingPlaceholder: b.customOptions?.engravingPlaceholder,
      engravingMaxChars: b.customOptions?.engravingMaxChars,
      materials: JSON.stringify(b.customOptions?.materials || []),
      fonts: JSON.stringify(b.customOptions?.fonts || []),
      giftWrapAvailable: b.customOptions?.giftWrapAvailable ?? false,
      badge: b.badge,
      craftTimeDays: b.craftTimeDays ?? 1,
      material: b.material,
      sizeDimensions: b.sizeDimensions,
      shippingInfo: b.shippingInfo,
      artisanBio: artisan.bio,
      artisanLocation: artisan.location,
      artisanAvatar: artisan.avatar,
      artisanSpecialty: artisan.specialty,
    },
  });
  res.status(201).json({ product: serialize(product) });
});

// Artisan: update own product
router.patch('/:id', attachUser, requireRole('artisan'), async (req, res) => {
  const product = await prisma.product.findUnique({ where: { id: req.params.id } });
  if (!product) return res.status(404).json({ error: 'Product not found' });
  if (product.artisanId !== req.user!.userId) {
    return res.status(403).json({ error: 'You can only edit your own products' });
  }

  const b = req.body || {};
  const updated = await prisma.product.update({
    where: { id: product.id },
    data: {
      ...('title' in b ? { title: b.title } : {}),
      ...('description' in b ? { description: b.description } : {}),
      ...('price' in b ? { price: b.price } : {}),
      ...('inStock' in b ? { inStock: b.inStock } : {}),
      ...('stockCount' in b ? { stockCount: b.stockCount } : {}),
      ...('status' in b ? { status: b.status } : {}),
      ...('image' in b ? { image: b.image } : {}),
      ...('images' in b ? { images: JSON.stringify(b.images) } : {}),
    },
  });
  res.json({ product: serialize(updated) });
});

// Artisan: delete own product
router.delete('/:id', attachUser, requireRole('artisan'), async (req, res) => {
  const product = await prisma.product.findUnique({ where: { id: req.params.id } });
  if (!product) return res.status(404).json({ error: 'Product not found' });
  if (product.artisanId !== req.user!.userId) {
    return res.status(403).json({ error: 'You can only delete your own products' });
  }
  await prisma.product.delete({ where: { id: product.id } });
  res.json({ ok: true });
});

export default router;
