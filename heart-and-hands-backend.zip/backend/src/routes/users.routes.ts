import { Router } from 'express';
import { prisma } from '../lib/prisma';
import { attachUser, requireAuth, requireRole } from '../middleware/auth';

const router = Router();

function toPublicUser(u: any) {
  const { passwordHash, googleId, ...rest } = u;
  return rest;
}

// Update own profile
router.patch('/me', attachUser, requireAuth, async (req, res) => {
  const b = req.body || {};
  const updated = await prisma.user.update({
    where: { id: req.user!.userId },
    data: {
      ...('fullName' in b ? { fullName: b.fullName } : {}),
      ...('phoneNumber' in b ? { phoneNumber: b.phoneNumber } : {}),
      ...('avatar' in b ? { avatar: b.avatar } : {}),
      ...('bio' in b ? { bio: b.bio } : {}),
      ...('shopName' in b ? { shopName: b.shopName } : {}),
      ...('location' in b ? { location: b.location } : {}),
      ...('specialty' in b ? { specialty: b.specialty } : {}),
      ...('categories' in b ? { categories: JSON.stringify(b.categories) } : {}),
      ...('instagramId' in b ? { instagramId: b.instagramId } : {}),
    },
  });
  res.json({ user: toPublicUser(updated) });
});

// Public artisan storefront profile
router.get('/artisan/:id', async (req, res) => {
  const artisan = await prisma.user.findUnique({ where: { id: req.params.id } });
  if (!artisan || artisan.role !== 'artisan') {
    return res.status(404).json({ error: 'Artisan not found' });
  }
  res.json({ artisan: toPublicUser(artisan) });
});

// Artisan: earnings summary, derived live from orders (no duplicated ledger table)
router.get('/artisan/me/earnings', attachUser, requireRole('artisan'), async (req, res) => {
  const artisanId = req.user!.userId;
  const items = await prisma.orderItem.findMany({
    where: { artisanId },
    include: { order: true },
  });

  let totalSales = 0;
  let completedOrdersCount = 0;
  let pendingPayments = 0;
  let availableEarnings = 0;
  const earningsHistory = items.map(it => {
    totalSales += it.totalPrice;
    const isCompleted = ['Delivered', 'Completed'].includes(it.order.status);
    if (isCompleted) {
      completedOrdersCount += 1;
      availableEarnings += it.totalPrice;
    } else {
      pendingPayments += it.totalPrice;
    }
    return {
      id: it.id,
      orderNumber: it.order.orderNumber,
      date: it.order.createdAt,
      amount: it.totalPrice,
      status: isCompleted ? 'Available' : 'Pending',
      customerName: it.order.customerName,
    };
  });

  res.json({
    earnings: { totalSales, completedOrdersCount, pendingPayments, availableEarnings, earningsHistory },
  });
});

export default router;
