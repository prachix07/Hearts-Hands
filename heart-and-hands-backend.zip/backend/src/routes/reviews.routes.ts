import { Router } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { prisma } from '../lib/prisma';
import { attachUser, requireRole } from '../middleware/auth';

const router = Router();

// Public: reviews for a product
router.get('/product/:productId', async (req, res) => {
  const reviews = await prisma.productReview.findMany({
    where: { productId: req.params.productId },
    orderBy: { date: 'desc' },
  });
  res.json({ reviews });
});

// Customer: leave a review for a delivered order item
router.post('/', attachUser, requireRole('customer'), async (req, res) => {
  const b = req.body || {};
  const order = await prisma.order.findUnique({ where: { id: b.orderId } });
  if (!order || order.customerId !== req.user!.userId) {
    return res.status(403).json({ error: 'You can only review your own orders' });
  }

  const review = await prisma.productReview.create({
    data: {
      id: uuidv4(),
      productId: b.productId,
      orderId: b.orderId,
      customerId: req.user!.userId,
      customerName: order.customerName,
      rating: b.rating,
      comment: b.comment,
      customDetailsSummary: b.customDetailsSummary,
    },
  });

  // Recompute product rating/reviewCount.
  const agg = await prisma.productReview.aggregate({
    where: { productId: b.productId },
    _avg: { rating: true },
    _count: { rating: true },
  });
  await prisma.product.update({
    where: { id: b.productId },
    data: { rating: agg._avg.rating || 0, reviewCount: agg._count.rating },
  });

  res.status(201).json({ review });
});

// Artisan: reply to a review on one of their products
router.patch('/:id/reply', attachUser, requireRole('artisan'), async (req, res) => {
  const review = await prisma.productReview.findUnique({
    where: { id: req.params.id },
    include: { product: true },
  });
  if (!review) return res.status(404).json({ error: 'Review not found' });
  if (review.product.artisanId !== req.user!.userId) {
    return res.status(403).json({ error: 'You can only reply to reviews on your own products' });
  }

  const updated = await prisma.productReview.update({
    where: { id: review.id },
    data: { artisanReply: req.body?.reply },
  });
  res.json({ review: updated });
});

export default router;
