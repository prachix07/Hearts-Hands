import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import { ALLOWED_ORIGINS } from './lib/oauth';

import authRoutes from './routes/auth.routes';
import productRoutes from './routes/products.routes';
import orderRoutes from './routes/orders.routes';
import reviewRoutes from './routes/reviews.routes';
import notificationRoutes from './routes/notifications.routes';
import userRoutes from './routes/users.routes';

const app = express();

app.use(cors({ origin: ALLOWED_ORIGINS, credentials: true }));
app.use(express.json());
app.use(cookieParser());

app.get('/health', (_req, res) => res.json({ ok: true }));

app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/reviews', reviewRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/users', userRoutes);

// This backend is purely an API — it does NOT serve or alter the existing
// frontend. Deploy it as a separate service and point the frontend's API
// base URL at it (or proxy /api/* to it from the existing frontend host).

const PORT = Number(process.env.PORT) || 8080;
app.listen(PORT, () => {
  console.log(`Heart & Hands API listening on port ${PORT}`);
});
