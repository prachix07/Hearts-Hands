# Heart & Hands — Backend API

This is a standalone API backend for the site at heart-hands-1.ai.studio. **It does not
touch or replace anything in your frontend** — `index.html`, `index.css`, and your React
components are untouched. This just gives the frontend something real to talk to over
`fetch`/`axios` for accounts, products, orders, reviews, and notifications.

## Where customer data is stored

By default: **a single SQLite file at `backend/data/heart-hands.db`**, created
automatically the first time you run a migration. Every user, product, order, review,
and notification lives in that one file.

**Important — read before deploying:** your app is hosted on Cloud Run (the
`asia-southeast1.run.app` URLs in your `oauth.ts`). Cloud Run containers have no
persistent disk — the filesystem is wiped every time the service restarts, scales, or
you redeploy. If you ship this as-is with SQLite, **customer accounts and orders will
disappear** the next time the container restarts. This is the single most important
thing to fix before you have real customers.

The fix (no code changes to routes, just one file):
1. Get a free Postgres database — [Supabase](https://supabase.com), [Neon](https://neon.tech),
   or Google Cloud SQL if you want to stay inside Google Cloud.
2. In `prisma/schema.prisma`, change `provider = "sqlite"` to `provider = "postgresql"`.
3. Put the connection string Supabase/Neon/Cloud SQL gives you into `DATABASE_URL` in
   your `.env`.
4. Run `npm run prisma:deploy`.

Everything else — every route, every query — works identically against either database.

## What's included

- `prisma/schema.prisma` — the full data model, built directly from your `types.ts`
  (User, Product, Order + OrderItem + timeline, ProductReview, ArtisanNotification).
  Artisan earnings are computed live from order data rather than stored separately, so
  there's no duplicate bookkeeping to keep in sync.
- `src/lib/oauth.ts` — **your existing file, unchanged.** Reused as-is for redirect URI
  resolution and allowed origins/callbacks.
- `src/routes/auth.routes.ts` — email/password register & login (bcrypt-hashed
  passwords, never stored in plain text), plus a full Google OAuth flow built on your
  existing `oauth.ts` helpers.
- `src/routes/products.routes.ts`, `orders.routes.ts`, `reviews.routes.ts`,
  `notifications.routes.ts`, `users.routes.ts` — CRUD for every entity in your types,
  with role checks (a customer can't edit someone else's product; an artisan can only
  update orders containing their own items, etc.).
- Sessions are JWTs in an httpOnly cookie (also returned in the response body for
  mobile/non-cookie clients), signed with `JWT_SECRET`.

## Setup

```bash
cd backend
cp .env.example .env
# edit .env: set JWT_SECRET, and GOOGLE_CLIENT_ID/SECRET if you want Google login
npm install
npm run prisma:migrate     # creates backend/data/heart-hands.db and the tables
npm run dev                 # starts the API on http://localhost:8080
```

Health check: `GET http://localhost:8080/health`

## Connecting your existing frontend

Nothing in your frontend needs to change structurally — just point your API calls at
this server's base URL (e.g. `http://localhost:8080/api` in dev, or wherever you deploy
this to in production) and include `credentials: 'include'` on fetch calls so the
session cookie is sent:

```ts
fetch(`${API_BASE_URL}/api/auth/login`, {
  method: 'POST',
  credentials: 'include',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email, password }),
});
```

## API overview

| Method | Path | Auth | Purpose |
|---|---|---|---|
| POST | `/api/auth/register` | — | Create customer or artisan account |
| POST | `/api/auth/login` | — | Email/password login |
| POST | `/api/auth/logout` | — | Clear session |
| GET | `/api/auth/me` | session | Current user |
| GET | `/api/auth/google/start` | — | Begin Google OAuth |
| GET | `/api/auth/google/callback` | — | Google OAuth callback |
| GET | `/api/products` | — | List/search products |
| GET | `/api/products/:id` | — | Product detail |
| POST | `/api/products` | artisan | Create product |
| PATCH | `/api/products/:id` | artisan (owner) | Update product |
| DELETE | `/api/products/:id` | artisan (owner) | Delete product |
| POST | `/api/orders` | customer | Place an order |
| GET | `/api/orders/mine` | customer | My orders |
| GET | `/api/orders/artisan/mine` | artisan | Orders containing my products |
| GET | `/api/orders/:id` | owner/involved artisan | Order detail |
| PATCH | `/api/orders/:id/status` | artisan | Update status (adds timeline event) |
| GET | `/api/reviews/product/:productId` | — | Reviews for a product |
| POST | `/api/reviews` | customer | Leave a review |
| PATCH | `/api/reviews/:id/reply` | artisan (owner) | Reply to a review |
| GET | `/api/notifications` | artisan | My notifications |
| PATCH | `/api/notifications/:id/read` | artisan | Mark read |
| PATCH | `/api/users/me` | session | Update own profile |
| GET | `/api/users/artisan/:id` | — | Public artisan storefront profile |
| GET | `/api/users/artisan/me/earnings` | artisan | Earnings summary |

## A note on this build

I generated this against your `types.ts` and `oauth.ts` exactly as given. I could not run
`npm run prisma:generate` inside this sandboxed environment because it blocks the
domain Prisma downloads its engine binaries from — that restriction is specific to this
chat's sandbox, not your project, and will not affect you running `npm install` /
`npm run prisma:migrate` normally on your own machine or in a Cloud Run build. Do run
`npm run prisma:migrate` locally before deploying, just to confirm the schema builds
cleanly in your environment.
